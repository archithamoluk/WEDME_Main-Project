<?php
$SETTINGS["hostname"]='localhost';
$SETTINGS["mysql_user"]='REPLACE';
$SETTINGS["mysql_pass"]='REPLACE';
$SETTINGS["mysql_database"]='REPLACE';
$SETTINGS["data_table"]='registrations';
$SETTINGS["paypal_address"]='email@domain.com';
?>